


<!DOCTYPE HTML>
<html>  

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id =  $_POST['id'];

$sql = "SELECT * FROM `major` WHERE id = $id";

$result = $conn->query($sql);

$row = $result->fetch_assoc();

?>

<body>
<?php ?>
<form action="major_edix_2.php" method="post" style="padding:20px;">
ID:<input type="number" name="id" value="<?php echo $row['id'];?>"><br>
Name: <input type="text" name="name" value="<?php echo $row['name_major'];?>"><br>
<input type="submit" value="Sửa" onclick="return confirm('Bạn có chắc chắn muốn xóa chuyên ngành này?')">
</form>

</body>
</html>
