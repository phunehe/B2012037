
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thêm chuyên ngành</title>
</head>
<body style="padding:10px;">
  <h2>Thêm chuyên ngành vào danh sách</h2><br/>
  <form action="major_edix_save.php" method="post" style="width:300px;display:flex;flex-direction: column;" >
    <label for="name">Nhập id: </label>
    <input type="number" class="name" name='id' min="1" placeholder="ID"><br/>
    <label for="name">Nhập tên ngành học: </label>
    <input type="text" class="name" name='name' placeholder="Nhap vao ten nganh">
    <input type="submit" value="Thêm"><br/>
  </form>
</body>
</html>