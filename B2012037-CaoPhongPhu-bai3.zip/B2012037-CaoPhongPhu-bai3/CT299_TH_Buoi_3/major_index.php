

<?php 
  // Kết nối CSDL

  $conn = mysqli_connect("localhost", "root", "", "qlsv");

  // Lấy dữ liệu từ bảng major
  $result = mysqli_query($conn, "SELECT * FROM major");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Danh sách chuyên ngành</title>
</head>
<body>
  <h1>Danh sách chuyên ngành</h1>
  <a href="major_add.php">Thêm chuyên ngành mới</a>
  <table border="1" style="margin-top:10px;">
    <tr>
      <th>ID</th>
      <th>Tên chuyên ngành</th>
      <th>Thao tác</th>
    </tr>
    <?php while($row = mysqli_fetch_array($result)) { ?>
    <tr>
      <td><?php echo $row['id']; ?></td>
      <td><?php echo $row['name_major']; ?></td>
      <td style="display:flex;padding:2px;">  
      <form method="post" action="major_edix.php"> 
        <input type="submit" name="action"  value="sua"/>
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
        </form>
        <form method="post" action="major_xoa.php"> 
        <input type="submit" name="action"  value="xoa" onclick="return confirm('Bạn có chắc chắn muốn xóa chuyên ngành này?')" />
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"/>
        </form>
      </td>
    </tr>
    <?php } ?>
  </table>
</body>
</html>
